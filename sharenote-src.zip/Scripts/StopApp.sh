#!/bin/bash

sudo killall java
exit 0